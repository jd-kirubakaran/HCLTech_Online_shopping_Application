
let ans1 = "React";
let ans2 ="sleeping";

let que;

if(ans1){
    console.log(`I am working in + ${ans1}`);
    
}else{
    console.log(`I am working in + ${ans2}`);
}