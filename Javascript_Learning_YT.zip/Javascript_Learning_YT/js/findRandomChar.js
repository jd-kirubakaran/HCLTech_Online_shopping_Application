// let dtTest = "Hello Universe";
// console.log(typeof dtTest);





let myCharRandomName= "Joseph Deva Kirubakaran";

const logicRandom = Math.floor(Math.random() *myCharRandomName.length)


console.log(myCharRandomName.charAt(logicRandom));


